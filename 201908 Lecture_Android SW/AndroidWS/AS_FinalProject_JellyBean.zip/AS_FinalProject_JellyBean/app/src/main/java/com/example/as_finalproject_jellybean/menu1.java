package com.example.as_finalproject_jellybean;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class menu1 extends AppCompatActivity
{
    TextView mTextView;
    Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        mTextView = (TextView)findViewById(R.id.info_text1);
        mButton = (Button)findViewById(R.id.info_btn1);

        mTextView.setText("추천메뉴\n\n" +
                "우동(현금 2500) + \n" +
                "김밥(우동 주문시 1000)\n\n" +
                "= 총 3500원");
        mButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }
}