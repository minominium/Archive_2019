package com.example.as_finalproject_jellybean;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class Main2Activity extends AppCompatActivity
{
    private Random ran = new Random();
    private int r;
    private Button btn_Info;
    private Button btn_Dinner1;
    private Button btn_Dinner2;
    private Button btn_Dinner3;
    private Button btn_Dinner4;
    private Button btn_Dinner5;
    private Button btn_Dinner6;
    private Handler timer = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn_Dinner1 = (Button) findViewById(R.id.marker1);
        btn_Dinner2 = (Button) findViewById(R.id.marker2);
        btn_Dinner3 = (Button) findViewById(R.id.marker3);
        btn_Dinner4 = (Button) findViewById(R.id.marker4);
        btn_Dinner5 = (Button) findViewById(R.id.marker5);
        btn_Dinner6 = (Button) findViewById(R.id.marker6);

        btn_Info = (Button)findViewById(R.id.minos_ltds);
        btn_Info.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(Main2Activity.this, PopupActivity.class));
            }
        });

        btn_Dinner1.setBackgroundResource(R.drawable.marker_red);
        btn_Dinner2.setBackgroundResource(R.drawable.marker_red);
        btn_Dinner3.setBackgroundResource(R.drawable.marker_red);
        btn_Dinner4.setBackgroundResource(R.drawable.marker_red);
        btn_Dinner5.setBackgroundResource(R.drawable.marker_red);
        btn_Dinner6.setBackgroundResource(R.drawable.marker_red);
        r = (ran.nextInt(180) % 6);
        switch(r)
        {
            case 0:
                btn_Dinner1.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner1.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu1.class));
                    }
                });
                break;
            case 1:
                btn_Dinner2.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner2.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu2.class));
                    }
                });
                break;
            case 2:
                btn_Dinner3.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner3.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu3.class));
                    }
                });
                break;
            case 3:
                btn_Dinner4.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner4.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu4.class));
                    }
                });
                break;
            case 4:
                btn_Dinner5.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner5.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu5.class));
                    }
                });
                break;
            case 5:
                btn_Dinner6.setBackgroundResource(R.drawable.marker_blue);
                btn_Dinner6.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        startActivity(new Intent(Main2Activity.this, menu6.class));
                    }
                });
                break;
            default:
                break;
        }
    }
}
