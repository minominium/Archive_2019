package com.example.as_finalproject_jellybean;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class PopupActivity extends AppCompatActivity
{
    TextView mTextView;
    Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);

        mTextView = (TextView)findViewById(R.id.info_text);
        mButton = (Button)findViewById(R.id.info_btn);

        mTextView.setText("Minos ULtd.\n\n\n" +
                          "늦게 내서 정말 죄송합니다\n" +
                          "박광현 교스님.");
        mButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }
}
